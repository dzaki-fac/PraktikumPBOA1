public class CartItem {
    private Product product;
    private int quantity;

    public CartItem(Product product, int quantity) {
        assert product != null : "Product tidak boleh null";

        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity harus > 0");
        }

        this.product = product;
        this.quantity = quantity;
    }

    // Getter
    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    // Setter
    public void setProduct(Product product) {
        this.product = product;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getSubtotal() {
        return product.getPrice() * quantity;
    }
}